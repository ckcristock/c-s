<?php

namespace App\Interfaces;

interface PorcentajeInterface
{
    public function calculateIngresoDeIncapacidad();
}
