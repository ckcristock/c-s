<?php

namespace App\Http\Controllers;

use App\Models\Company;
use App\Models\WorkContract;
use App\Traits\ApiResponser;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\URL;

class CompanyController extends Controller
{
    use ApiResponser;
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        return $this->success(Company::all(['id as value','name as text']));
    }

    public function getBasicData()
    {
        return $this->success(
            Company::with('arl')->with('bank')->first()
        );
    }

    public function saveCompanyData(Request $request) 
    {
        return $this->success(
            $company = Company::findOrFail($request->get('id')),
            $company->update($request->all())
        );
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $data = $request->all();
        $typeImage = '.' . $request->typeImage;
        $data["logo"] = URL::to('/') . '/api/image?path=' . saveBase64($data['logo'], 'companies/', true, $typeImage);
        dd($data);
        try {
            WorkContract::find($request->get('id'))->update($data);
            return response()->json(['message' => 'Se ha actualizado con éxito']);
        } catch (\Throwable $th) {
            return $this->error($th->getMessage(), 500);
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
     
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    public function getGlobal()
    {
        return Company::with('payConfiguration')->with('arl')->first([
            'id', 'arl_id', 'payment_frequency', 'social_reason', 'document_number',
            'transportation_assistance', 'base_salary', 'law_1607'
        ]);
    }
}
