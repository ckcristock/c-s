<?php

namespace App\Http\Controllers;

use App\Models\CalculationBase;
use App\Traits\ApiResponser;
use Illuminate\Http\Request;

class CalculationBaseController extends Controller
{
    use ApiResponser;
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        return $this->success( CalculationBase::all() );
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
      
        
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function updateAll(Request $request)
    {
        //
        $toCreate = $request->get('data');
        //
        try {
            foreach ($toCreate as $value) {
                $base = CalculationBase::where('concept',$value[0])->first();
                $base->value = $value[1];
                $base->save();
            }

            return $this->success('creado con éxito');
           
        } catch (\Throwable $th) {
            //throw $th;
            return $this->errorResponse( $th->getFile().$th->getMessage() );

        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
